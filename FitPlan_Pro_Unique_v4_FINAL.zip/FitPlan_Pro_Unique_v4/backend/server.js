import express from 'express';
import cors from 'cors';
import multer from 'multer';
import dotenv from 'dotenv';
dotenv.config();
const app=express();
const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:8*1024*1024}});
app.use(cors());app.use(express.json({limit:'1mb'}));
app.get('/health',(req,res)=>res.json({ok:true,service:'FitPlan Pro Unique v4'}));
app.post('/api/coach',async(req,res)=>{
  const {question,profile,today}=req.body||{};
  if(!question)return res.status(400).json({error:'question gerekli'});
  // Gerçek AI sağlayıcısını burada, sunucu tarafında çağır.
  // AI_API_KEY hiçbir zaman frontend'e gönderilmez.
  if(process.env.AI_API_URL&&process.env.AI_API_KEY){
    try{
      const r=await fetch(process.env.AI_API_URL,{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${process.env.AI_API_KEY}`},body:JSON.stringify({model:process.env.AI_MODEL,messages:[{role:'system',content:'Türkçe yanıt ver. Beslenme/fitness konusunda genel, güvenli ve sürdürülebilir öneriler sun; teşhis veya tıbbi tedavi verme.'},{role:'user',content:JSON.stringify({question,profile,today})}]})});
      const d=await r.json();
      const answer=d?.choices?.[0]?.message?.content||d?.output_text;
      if(answer)return res.json({answer});
    }catch(e){console.error(e)}
  }
  res.json({answer:'Sunucu AI sağlayıcısı henüz yapılandırılmamış. Şimdilik uygulamanın yerel koçu kullanılabilir.'});
});
app.post('/api/analyze-image',upload.single('image'),async(req,res)=>{
  if(!req.file)return res.status(400).json({error:'image gerekli'});
  // Gerçek görsel model çağrısını burada sunucu tarafında yap.
  res.json({summary:'Fotoğraf sunucuya ulaştı. Görsel AI sağlayıcısı yapılandırıldığında yemek, tahmini porsiyon ve besin analizi döndürülebilir.'});
});
app.listen(process.env.PORT||8787,()=>console.log(`FitPlan backend :${process.env.PORT||8787}`));
